LAURENCE S. SEGUNDO JR. — PORTFOLIO WEBSITE

FILES
- index.html
- style.css
- script.js
- images/ (put your pictures here)

ADD YOUR PHOTOS
Put your own image files inside the images folder and use these exact filenames:
1. profile.jpg             - homepage portrait
2. senior-high.jpg         - senior high school event photo
3. graduation.jpg          - graduation portrait in the education section
4. cheerdance-champion.jpg - Milo Cheerdance Competition 2026 photo
5. gymnastics-early.jpg    - early gymnastics team photo
6. gymnastics.jpg          - gymnastics team/medal photo
7. father.jpg              - family section, father photo
8. mother.jpg              - family section, mother photo
9. friends.jpg             - friends photo

You can use .png instead, but if you do, update the matching image filename in index.html.
Keep the images folder beside index.html, not inside another folder.

PREVIEW
Open index.html in a browser. For best results, use VS Code with the Live Server extension.

GITHUB PAGES
1. Create a GitHub repository.
2. Upload index.html, style.css, script.js, and the entire images folder.
3. Open repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select main and /(root), then Save.
6. Wait for the published site link to appear in the Pages section.

PRIVACY
This starter portfolio does not publish a mobile number or personal email address.
Think carefully before putting personal contact details on a public website.
